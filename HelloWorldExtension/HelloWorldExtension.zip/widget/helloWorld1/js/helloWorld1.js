define(
  [],
  function () {
      "use strict";
      return {
        onLoad : function (widget) {
        },
        beforeAppear : function (page) {
          alert("hello world1");
        }
      };
  }
);
